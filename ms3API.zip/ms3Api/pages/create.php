<?php include_once("crudOperations.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container"> 
    <h2 class="text-center" >Create User</h2>
    <class="row">
       <!--  <div class="alert alert-success col-md-offset-3 col-md-6">
                <strong>Success!</strong>
        </div> -->
        <form class="form-horizontal  col-md-offset-3 col-md-6" >    
        <h3>personal Indentification </h3>       
            <div class="form-group">
                
                <div class="col-sm-10">
                <label>First Name</label>
                <input type="text" class="form-control" id="first_name" name="first_name" placeholder="Enter First Name">
                </div>
            </div>
            <div class="form-group">
               
                <div class="col-sm-10">
                <label>Last Name</label>
                <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Enter Last Name">
                </div>
            </div>
            <div class="form-group">                
                <div class="col-sm-10">
                <label>DOB </label>
                <input type="date" class="form-control" id="dob" name="dob" placeholder="Enter DOB ">
                </div>
            </div>
                <div class="form-group">
                
                <div class="col-sm-10">
                <label>Gender</label>
                <input type="text" class="form-control" id="gender" name="gender" placeholder="Enter Gender">
                </div>
            </div>
            <div class="form-group">
               
                <div class="col-sm-10">
                <label>Title</label>
                <input type="text" class="form-control" id="title" name="title" placeholder=" Enter Title">
                </div>
            </div>
            <h3>Address</h3>
            <div class="form-group">                
                <div class="col-sm-5">
                <label>Type</label>
                <input type="text" class="form-control" id="address" name="address" placeholder="Address">
                </div>

                <div class="col-sm-5">
                <label>Number</label>
                <input type="text" class="form-control" id="num" name="num" placeholder="Enter Number">
                </div>
            </div>

             <div class="form-group">                
                <div class="col-sm-5">
                <label>Street</label>
                <input type="text" class="form-control" id="street" name="street" placeholder="Enter Street">
                </div>

                <div class="col-sm-5">
                <label>Unit</label>
                <input type="text" class="form-control" id="unit" name="unit" placeholder="Enter Unit">
                </div>
            </div>

             <div class="form-group">                
                <div class="col-sm-5">
                <label>City</label>
                <input type="text" class="form-control" id="city" name="city" placeholder="Enter  City">
                </div>

                <div class="col-sm-5">
                <label>State</label>
                <input type="text" class="form-control" id="state" name="state" placeholder="Enter State">
                </div>
            </div>

             <div class="form-group">                
                <div class="col-sm-5">
                <label>Zip Code</label>
                <input type="text" class="form-control" id="zip" name="zip" placeholder="Enter Zip">
                </div>

                
            </div>
            <h3>Communication</h3>
             <div class="form-group">                
                <div class="col-sm-10">
                <label>Type</label>
                <select id="communication_type" name="type" class="form-control">
                <option value="">Select Communication Type</option>
                <option value="email">Email</option>
                <option value="phone">Cell Phone</option>
                </select> 
                </div>
                               
            </div>
             <div class="form-group"> 
            <div class="col-sm-5">

                <label>Value</label>
                <input type="text" class="form-control" id="value" name="value" placeholder="Enter Value">
                <input type="checkbox" name="preferred" id="preferred" name="preferred" value="preferred"> Preferred?  <br>
                </div>
           </div>

          <input type="submit" class="btn btn-info" value="Submit Button">
        </form>
               

    </div>   
    <div></div>       
</div>



</body>
</html>
