<?php
include_once("crudOperations.php"); 
$fetchdata=new DB_con();
 ?>
 <table class="table table-hover" border="1">
    <thead>
      <tr>
         <th>Firstname</th>
          <th>Lastname</th>
          <th>DOB</th>
          <th>Gender</th>
          <th>Title</th>
          <th>Type</th>
          <th>Number</th>
          <th>Unity</th>
          <th>City</th>
          <th>State</th>
          <th>ZipCode</th>
          <th>Communication Type</th>
          <th>Communication Value</th>
          <th>Perefered</th>
          <th>Edit</th>
          <th>Delete</th>
     </tr>     
  <?php
  $sql=$fetchdata->fetchdata();
  $cnt=1;
  while($row=mysqli_fetch_array($sql))
  {
  ?>
  <tr>
   <td height="29"><?php echo $cnt;?></td>
    <td><?php echo $row['first_name'];?></td>
    <td><?php echo $row['last_name'];?></td>
    <td><?php echo $row['DOB'];?></td>
    <td><?php echo $row['title'];?></td>
    <td><?php echo $row['type'];?></td>
    <td><?php echo $row['num'];?></td>
    <td><?php echo $row['unity'];?></td>
    <td><?php echo $row['city'];?></td>
    <td><?php echo $row['state'];?></td>
    <td><?php echo $row['zipcode'];?></td>
    <td><?php echo $row['com_type'];?></td>
    <td><?php echo $row['value'];?></td>
    <td><?php echo $row['perefered'];?></td>
    <td><?php update() ?></td> 
    <td><?php delete() ?></td> 
  </tr>
  <?php $cnt=$cnt+1;} ?>
</table>