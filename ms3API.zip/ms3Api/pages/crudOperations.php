<?php

include_once("connection.php");
$fetchdata=new DB_con();
 
class DB_con
{
 function __construct()
 {
  $conn = mysql_connect(DB_SERVER,DB_USER,DB_PASS) or die('localhost connection problem'.mysql_error());
  mysql_select_db(DB_NAME, $conn);
 }

 public function insert()
 {
 	if (isset($_POST['submit'])) {
   		  $first_name = mysqli_real_escape_string($con,$_POST['first_name']);
          $last_name = mysqli_real_escape_string($con,$_POST['last_name']);
          $dob = mysqli_real_escape_string($con,$_POST['dob']);
          $gender = mysqli_real_escape_string($con,$_POST['gender']);  
          $title = mysqli_real_escape_string($con,$_POST['title']);

          $type = mysqli_real_escape_string($con,$_POST['type']);
          $num = mysqli_real_escape_string($con,$_POST['num']);
          $street = mysqli_real_escape_string($con,$_POST['street']);
          $unit = mysqli_real_escape_string($con,$_POST['unit']);          
          $city = mysqli_real_escape_string($con,$_POST['city']);
          $state = mysqli_real_escape_string($con,$_POST['state']);         
          $zip = mysqli_real_escape_string($con,$_POST['zip']);
         
          $communication_type = mysqli_real_escape_string($con,$_POST['communication_type']);
          $value = mysqli_real_escape_string($con,$_POST['value']);
          $preferred = mysqli_real_escape_string($con,$_POST['preferred']);      
        
         
          $insert_identification = "INSERT INTO identification(first_name,last_name,dob,gender,title) VALUES ('$first_name','$last_name','$dob','$gender','$title')";
          $insert_address = "INSERT INTO address(type,num,street,unit,city,state,zip) VALUES ('$type','$num','$street','$unit','$city',state,zip)";
          $insert_communication = "INSERT INTO communication(communication_type,value,preferred) VALUES ('$communication_type','$value','$preferred')";

          $run_insert = mysqli_query($con,$insert_identification);
          $run_insert = mysqli_query($con,$insert_address);
          $run_insert = mysqli_query($con,$insert_communication); 
 } }
 
 public function delete()
 {
  
	 	$result = "DELETE first_name, last_name, dob, gender, title 
	 	FROM Identification 
	 	JOIN Address ON (Address.user_id=Identification.user_id)
	 	JOIN Communication ON (Communication.user_id=Identification.user_id) 	
	 	WHERE Identification.user_id =".$user_id;
	 	return $result;
 }
 
 public function update()
 {
  ;

	 	$query = "UPDATE first_name, last_name, dob, gender, title 
	 	FROM Identification 
	 	JOIN Address ON (Address.user_id=Identification.user_id)
	 	JOIN Communication ON (Communication.user_id=Identification.user_id)  
		SET Identification.first_name = '$first_name', 
	    	Identification.last_name = '$last_name',
	    	Identification.dob = '$dob',
	    	Identification.gender = '$gender',
	    	Identification.first_name = '$title', 

	    	Address.type = '$type',
	    	Address.num = '$num,',
	    	Address.unit = '$unit',
	    	Address.city = '$city',
	    	Address.state = '$state',
	    	Address.zipcode = '$zipcode',

	    	Communication.com_type = '$com_type',
	    	Communication.value = '$value',
	    	Communication.prefered = '$prefered'
	 
		WHERE Identification.user_id = '$user_id'";
 }

 public function fetchdata()
 {
 		 $result = mysql_query("SELECT * FROM Identification,Address, Communication where Identification.user_id = Address.user_id and Address.user_id = Communication.user_id");		 
		 return $result;
 }
}

?>