Contacts Management API File Package Readme File
Contents
1. Purpose of the Readme File
2. Description and Installation of API
3. Contents and Structure of the CRUD Operators 
	3.1. Contents of the Operations
	3.1. Contents of the Operations
4. Requirements for Running the API


1. Purpose of the Readme File

The Readme file provides the description and structural contents of the "Contacts Management API" product designed in response to coding challenge by MS3. 

2. Descriptions and Installation of API

The API specifically called ms3ContactAPI is intended to run the API that would conduct CURD operations for managing contacts and running them on the database of the company. The database is derived from as specified from the data model of MS3-ContactsManagementAPI-src.json code.

3. Contents and Function of the CRUD Operators 
3.1. Contents of the Operations
The API is specifically named as ms3ContactAPI and was designed on the MuleSoft Anypoint Studio executed using the RAML file orchestrated by running the userInformation.xml to generate the RESTful API flows. The CRUD operations manage the database with the functions of GET, PUT, POST and DELETE data on the database. 
3.2. Functions of the CRUD Operations
API Database Routes
#GET

GET: contacts/identification/"Getting All Users”
GET: /contacts/ “individual user information”
GET: /addresses/"Getting All Users Address"
GET: /communication/"Getting All Users Information"

#PUT

PUT: contacts/ “update individual user information” 

#POST

POST: /identification/"Creating new user Information"
POST: /address/"Creating new user Information"
POST: /communication/ "Creating new user Information"

#DELETE

DELETE: contacts/“delete individual user”
 
    

