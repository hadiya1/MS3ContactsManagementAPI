-- MS3-ContactAPI_DataModel-SQLDefinition_v0.1ewn.txt


-- Create a database for MS3 user Contact records
CREATE DATABASE IF NOT EXISTS msc3api;



--  table creating sql qurery

CREATE TABLE IF NOT EXISTS Identification(
  user_id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
  first_Name  VARCHAR(255) NOT NULL,
  last_name   VARCHAR(255) NOT NULL,
  DOB        DATE,
  gender     VARCHAR(10),
  title      VARCHAR(255)
);

-- Address table
CREATE TABLE IF NOT EXISTS Address(
  address_id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
  FOREIGN KEY user_id REFERENCES Identification (user_id),
  type       VARCHAR(255) NOT NULL,
  num      VARCHAR(255) NOT NULL,
  street     VARCHAR(255) NOT NULL,
  unit       VARCHAR(255),
  city       VARCHAR(255) NOT NULL,
  state      VARCHAR(100) NOT NULL,
  zipcode    VARCHAR(100) 
);

-- Communication table
CREATE TABLE IF NOT EXISTS Communication(
  comm_id    INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
  FOREIGN KEY user_id REFERENCES Identification (user_id),
  com_type       VARCHAR(255) NOT NULL,
  value      VARCHAR(255) NOT NULL,
  preferred  VARCHAR(10)
);

-- Insert sql query 
INSERT INTO Identification (FirstName, LastName, DOB, Gender, Title) VALUES ("Bob", "Frederick", "1980-06-21", "M", "Manager")
INSERT INTO Address (user_id, Type, Num, Street, Unit, City, State, Zipcode) VALUES (1, "home", "1234", "blah blah St", "1 a", "Somewhere", "WV", "12345")
INSERT INTO Communication (user_id, Type, Value, Preferred) VALUES (1, "email", "bfe@sample.com", 1)

--update sql query
--update user firstname, lastname and dob from user Identifiation table  
UPDATE `Idenification` SET `first_name` = 'john', `last_name` = 'piter', `DOB` = '1980-07-30', `gender` = 'M', `title` = 'Manager' WHERE `useridentification`.`user_id` = 1; 
--update user unit, state and zipcode from user Address table 
UPDATE `Address` SET `type` = 'home', `street` = 'blah blah st', `Unit` = '2 b', `City` = 'Somewhere', `State` = 'VW', `Zipcode` = '56665' WHERE `useridentification`.`user_id` = 1; 


-- Delete user data form the tables
DELETE * FROM `Identification` WHERE user_id = 1;
DELETE * FROM `Address` WHERE user_id = 1;
DELETE * FROM `Communication` WHERE user_id = 1;
